package com.example.jdbctest;

import static org.junit.jupiter.api.Assertions.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class JdbcAppTest {
    private Connection conn;
@BeforeEach
public void setup() throws ClassNotFoundException, SQLException{
    Class.forName("com.mysql.cj.jdbc.Driver");
    conn = DriverManager.getConnection("jdbc:mysql://localhost:3307/employees", "root", "123456@amypo");
    assertNotNull(conn, "Connection should be Established"); 
}
@Test
public void testInsertEmp() throws SQLException{
    int empid = 7;
    String empname = "Ashwin";
    String insertQuery = "INSERT INTO emp(empid,empname) VALUES (?,?)";
    try(PreparedStatement ps = conn.prepareStatement(insertQuery)){
        ps.setInt(1, empid);
        ps.setString(2, empname);
        int roweffected = ps.executeUpdate();
        assertEquals(1, roweffected,"One row should be inserted");
        String selectSql = "SELECT * FROM emp WHERE empid = ?";
        try(PreparedStatement selectPS = conn.prepareStatement(selectSql)){
            selectPS.setInt(1, empid);
            try(ResultSet rs = selectPS.executeQuery()){
                assertTrue(rs.next(), "Result set should have at least one row");
                assertEquals(empid, rs.getInt("empid"));     
                assertEquals(empname, rs.getString("empname"));
            }
        } // break time 03 :00 to 03 : 15
    }
}
@Test
public void testUpdateEmp() throws SQLException{
int empid = 3;
String empname = "VK";
String updateSql = "UPDATE emp SET empname = ? WHERE empid = ?";

try(PreparedStatement ps = conn.prepareStatement(updateSql)){
    ps.setString(1, empname);
    ps.setInt(2, empid);
    int rowaffected = ps.executeUpdate();
    assertEquals(1, rowaffected, "One row should be updated");

    String selectSQL = "SELECT * FROM emp WHERE empid = ?";
    try(PreparedStatement selectps = conn.prepareStatement(selectSQL)){
selectps.setInt(1, empid);
try(ResultSet rs = selectps.executeQuery()){
    assertTrue(rs.next(),"Reselt set should have at least one row");
    assertEquals(empid, rs.getInt("empid"));
    assertEquals(empname, rs.getString("empname"));
}   // take this update method and work on it take taken upto  02 : 30
    }
}
}
@Test
public void testViewEmp() throws SQLException{
String viewSql = "SELECT * FROM emp";
try(PreparedStatement ps = conn.prepareStatement(viewSql);
ResultSet rs = ps.executeQuery()){
int count = 0;
while (rs.next()) {
    System.out.println(rs.getInt("empid") + " " +rs.getString("empname"));
    count++;
}
assertTrue(count >=2, "There should be at least two employee's in the table");
}
}
@AfterEach
public void end() throws SQLException{
    if(conn != null && !conn.isClosed() ){
        conn.close();
    }
}
}

//Task 2
// need to use atleast 3 browser (chrome,firefox,IE,Edge,Safari,Opera)
// switch(input) 1 = chrome ,2 = fixefox , 3=IE
// 
